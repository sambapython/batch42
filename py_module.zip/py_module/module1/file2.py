print "file2"
def fun():
	print "this is fun in file2"



def main():
	# statements belongs only file2
	pass
if __name__ == "__main__":
	main()