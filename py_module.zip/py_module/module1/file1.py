print "file1"
def fun():
	print "this is fun in file1"



def main():
	# statements belongs only file1
	pass
if __name__ == "__main__":
	main()