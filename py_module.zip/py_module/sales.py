from module1 import file2
file2.fun()