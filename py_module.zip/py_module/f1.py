a=100
b=200
c=300
def fun():
	print "this is fun in f1 modified"
#fun()